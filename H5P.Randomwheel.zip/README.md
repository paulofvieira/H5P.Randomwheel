# H5P.Randomwheel
H5P activity Randomwheel

# Installation
1. Compresser l'ensemble des dossiers/fichiers dans une archive zip ( nom de l'archive : "H5P.Randomwheel" )
2. Changer l'extention zip en h5p
3. Vous devez avoir installé préalablement le plugin moodle h5p : https://moodle.org/plugins/mod_hvp
4. Il vous suffit maintenant d'importer la librairie sur votre plateforme pour se faire aller à l'adresse :

nom_de_votre_domaine/mod/hvp/library_list.php
